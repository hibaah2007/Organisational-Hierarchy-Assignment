# Organisational Hierarchy – Tree and Searching Assignment

## Aim
Represent a company organisational hierarchy using a general tree, perform
level-order traversal, and compare Linear Search with Binary Search.

## Hierarchy
CEO -> HR, Finance, IT
IT -> Development, Testing
Development -> Frontend, Backend

## Files
- `source_code/organisation.c` – complete C implementation
- `input/input.txt` – input/search data
- `output/output.txt` – sample execution output
- `trace_table/trace_table.txt` – traversal and search traces
- `complexity/complexity_analysis.txt` – time and space complexity
- `comparison/comparison_table.xlsx` – comparison table
- `report/Organisational_Hierarchy_Report.docx` – formatted assignment report

## Expected traversal
CEO HR Finance IT Development Testing Frontend Backend

## Search results
| Department | Linear | Binary |
|---|---:|---:|
| IT | 4 | 3 |
| Backend | 8 | 3 |
| HR | 2 | 2 |

## Complexity
- Level-order traversal: O(n)
- Linear Search: O(n) worst case
- Binary Search: O(log n) worst case
- Tree storage: O(n)

## Compilation
```bash
gcc source_code/organisation.c -o organisation
./organisation
```

## Conclusion
The general tree is suitable for organisational reporting. A sorted array with
Binary Search is suitable for efficient department searching.
