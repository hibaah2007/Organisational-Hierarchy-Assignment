#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CHILDREN 10
#define MAX_QUEUE 20

struct Node {
    char name[30];
    struct Node *children[MAX_CHILDREN];
    int childCount;
};

struct Node *createNode(const char *name) {
    struct Node *node = (struct Node *)malloc(sizeof(struct Node));
    strcpy(node->name, name);
    node->childCount = 0;

    for (int i = 0; i < MAX_CHILDREN; i++)
        node->children[i] = NULL;

    return node;
}

void addChild(struct Node *parent, struct Node *child) {
    if (parent->childCount < MAX_CHILDREN)
        parent->children[parent->childCount++] = child;
}

void levelOrder(struct Node *root) {
    struct Node *queue[MAX_QUEUE];
    int front = 0, rear = 0;

    queue[rear++] = root;

    printf("Level-order traversal:\n");

    while (front < rear) {
        struct Node *current = queue[front++];
        printf("%s ", current->name);

        for (int i = 0; i < current->childCount; i++)
            queue[rear++] = current->children[i];
    }

    printf("\n");
}

int linearSearch(char arr[][30], int n, const char *key, int *comparisons) {
    *comparisons = 0;

    for (int i = 0; i < n; i++) {
        (*comparisons)++;
        if (strcmp(arr[i], key) == 0)
            return i;
    }

    return -1;
}

int binarySearch(char arr[][30], int n, const char *key, int *comparisons) {
    int low = 0, high = n - 1;
    *comparisons = 0;

    while (low <= high) {
        int mid = (low + high) / 2;
        (*comparisons)++;

        int result = strcmp(arr[mid], key);

        if (result == 0)
            return mid;
        else if (result < 0)
            low = mid + 1;
        else
            high = mid - 1;
    }

    return -1;
}

int main(void) {
    /* Construct the organisational hierarchy */
    struct Node *CEO = createNode("CEO");
    struct Node *HR = createNode("HR");
    struct Node *Finance = createNode("Finance");
    struct Node *IT = createNode("IT");
    struct Node *Development = createNode("Development");
    struct Node *Testing = createNode("Testing");
    struct Node *Frontend = createNode("Frontend");
    struct Node *Backend = createNode("Backend");

    addChild(CEO, HR);
    addChild(CEO, Finance);
    addChild(CEO, IT);

    addChild(IT, Development);
    addChild(IT, Testing);

    addChild(Development, Frontend);
    addChild(Development, Backend);

    printf("COMPANY ORGANISATIONAL HIERARCHY\n");
    printf("--------------------------------\n");
    levelOrder(CEO);

    char departments[8][30] = {
        "CEO", "HR", "Finance", "IT",
        "Development", "Testing", "Frontend", "Backend"
    };

    /* Alphabetically sorted representation for binary search */
    char sortedDepartments[8][30] = {
        "Backend", "CEO", "Development", "Finance",
        "Frontend", "HR", "IT", "Testing"
    };

    const char *searchKeys[3] = {"IT", "Backend", "HR"};

    printf("\nSEARCH COMPARISON\n");
    printf("-----------------\n");
    printf("%-15s %-20s %-20s\n",
           "Department", "Linear Comparisons", "Binary Comparisons");

    for (int i = 0; i < 3; i++) {
        int linearComparisons, binaryComparisons;

        linearSearch(departments, 8, searchKeys[i], &linearComparisons);
        binarySearch(sortedDepartments, 8, searchKeys[i], &binaryComparisons);

        printf("%-15s %-20d %-20d\n",
               searchKeys[i], linearComparisons, binaryComparisons);
    }

    /* Free allocated memory */
    free(CEO);
    free(HR);
    free(Finance);
    free(IT);
    free(Development);
    free(Testing);
    free(Frontend);
    free(Backend);

    return 0;
}
